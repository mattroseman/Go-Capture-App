colormap(gray(256));
