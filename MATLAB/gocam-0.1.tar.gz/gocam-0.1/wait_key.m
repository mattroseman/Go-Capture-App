drawnow;
if (g_wait)
  fprintf(1, 'Press return to continue...');
  pause;
  fprintf(1, '\n');
end